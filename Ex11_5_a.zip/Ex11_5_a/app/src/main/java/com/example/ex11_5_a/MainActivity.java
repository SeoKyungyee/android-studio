package com.example.ex11_5_a;

import android.content.ClipData;
import android.media.RouteListingPreference;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView tvTitle, tv1, tv2;
    EditText editName, editPhone;
    Button btnAdd;
    ListView lv;
    ArrayList<Item> itemList;
    CustomAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        editName = (EditText) findViewById(R.id.editName);
        editPhone = (EditText) findViewById(R.id.editPhone);
        lv = (ListView) findViewById(R.id.lv);

        itemList = new ArrayList<Item>();
        adapter = new CustomAdapter();
        lv.setAdapter(adapter);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editName.getText().toString();
                String phone = editPhone.getText().toString();
                Toast.makeText(getApplicationContext(), name+phone, Toast.LENGTH_LONG).show();
                editName.setText("");
                editPhone.setText("");
                itemList.add(new Item(R.drawable.logo, name, phone));
                adapter.notifyDataSetInvalidated();
            }
        });
        };
    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return itemList.size();
        }

        @Override
        public Object getItem(int i) {
            return itemList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = LayoutInflater.from(MainActivity.this).inflate(R.layout.list_item, viewGroup, false);
            }
            Item item = itemList.get(i);

            ImageView itemImage = view.findViewById(R.id.imageView);
            TextView itemName = view.findViewById(R.id.textView);
            TextView itemDescription = view.findViewById(R.id.textView2);

            itemImage.setImageResource(item.imageResId);
            itemName.setText(item.name);
            itemDescription.setText(item.description);

            return view;
        }
    }

    private class Item {
        int imageResId;
        String name;
        String description;

        Item (int imageResId, String name, String description) {
            this.imageResId = imageResId;
            this.name = name;
            this.description = description;
        }
    }

}
