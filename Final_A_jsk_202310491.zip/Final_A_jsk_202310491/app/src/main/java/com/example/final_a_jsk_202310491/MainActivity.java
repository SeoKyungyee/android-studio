package com.example.final_a_jsk_202310491;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tvCreate, tvForgot;
    EditText editId1, editPw;
    Button btnLogin;
    String value1, value2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("기말고사 : 장서경(202310491)");
        tvCreate = (TextView) findViewById(R.id.tvCreate);
        tvForgot = (TextView) findViewById(R.id.tvForgot);
        editId1 = (EditText) findViewById(R.id.editId1);
        editPw = (EditText) findViewById(R.id.editPw);
        btnLogin = (Button) findViewById(R.id.btnLogin);

        registerForContextMenu(tvForgot);

        tvCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Second.class);
                startActivity(intent);
            }
        });

        Intent intent = getIntent();
        value1 = intent.getStringExtra("Id");
        value2 = intent.getStringExtra("Pw");

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editId1.getText().toString().equals(value1) && editPw.getText().toString().equals(value2)){
                    Intent intent = new Intent(getApplicationContext(), Third.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "아이디와- 비밀번호 확인", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1,0, "학과 홈페이지");
        menu.add(0, 2,0, "Hello LMS");
        menu.add(0, 3,0, "학과 대표 전화");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == 1){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://medis.shu.ac.kr"));
            startActivity(intent);
            return true;
        }

        if(item.getItemId() == 2){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://eclass.shu.ac.kr"));
            startActivity(intent);
            return true;
        }

        if(item.getItemId() == 3){
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:0234078678"));
            startActivity(intent);
            return true;
        }
        return false;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater mInflater = getMenuInflater();
        if(v == tvForgot){
            mInflater.inflate(R.menu.menu1, menu);
        }
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.tv1){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://portal.shu.ac.kr/Gateweb/CORE/WEB/CORW03O"));
            startActivity(intent);
            return true;
        }

        if(item.getItemId() == R.id.tv2){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://portal.shu.ac.kr/Gateweb/CORE/WEB/CORW03O"));
            startActivity(intent);
            return true;
        }
        return super.onContextItemSelected(item);
    }
}