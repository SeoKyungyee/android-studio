package com.example.final_a_jsk_202310491;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Second extends AppCompatActivity {
    EditText editName, editId2, editPw1, editPw2, editEmail, editNamed, editIdd, editPwd, editEmaild;
    Button btnCheck, btnSign;
    View dialogView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        setTitle("기말고사 : 장서경(202310491)");
        editName = (EditText) findViewById(R.id.editName);
        editId2 = (EditText) findViewById(R.id.editId2);
        editPw1 = (EditText) findViewById(R.id.editPw1);
        editPw2 = (EditText) findViewById(R.id.editPw2);
        editEmail = (EditText) findViewById(R.id.editEmail);
        btnCheck = (Button) findViewById(R.id.btnCheck);
        btnSign = (Button) findViewById(R.id.btnSign);

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!editPw1.getText().toString().equals("")){
                    if(editPw1.getText().toString().equals(editPw2.getText().toString())){
                        Toast.makeText(getApplicationContext(), "아이디와 비밀번호가 일치", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "아이디와 비밀번호가 일치하지 않음", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(), "내용을 입력하세요", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogView = (View) View.inflate(Second.this, R.layout.dialog, null);
                AlertDialog.Builder dlg = new AlertDialog.Builder(Second.this);
                dlg.setTitle("입력하신 로그인 정보입니다.");
                dlg.setView(dialogView);
                dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.putExtra("Id", editId2.getText().toString());
                        intent.putExtra("Pw", editPw1.getText().toString());
                        startActivity(intent);
                    }
                });
                dlg.setNegativeButton("취소", null);
                editNamed = (EditText) dialogView.findViewById(R.id.editNamed);
                editIdd = (EditText) dialogView.findViewById(R.id.editIdd);
                editPwd = (EditText) dialogView.findViewById(R.id.editPwd);
                editEmaild = (EditText) dialogView.findViewById(R.id.editEmaild);

                editNamed.setText(editName.getText().toString());
                editIdd.setText(editId2.getText().toString());
                editPwd.setText(editPw1.getText().toString());
                editEmaild.setText(editEmail.getText().toString());
                dlg.show();
            }
        });
    }
}