package com.example.final_a_jsk_202310491;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;

public class Third extends AppCompatActivity {
    EditText editDate, editTime, editTitle, editCon;
    String dateName, timeName, fileName;
    Button btnSave, btnSign;
    ListView lv;
    ArrayList<Item> itemList;
    CustomAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.third);
        setTitle("기말고사 : 장서경(202310491)");
        editDate = (EditText) findViewById(R.id.editDate);
        editTime = (EditText) findViewById(R.id.editTime);
        editTitle = (EditText) findViewById(R.id.editTitle);
        editCon = (EditText) findViewById(R.id.editCon);
        btnSave = (Button) findViewById(R.id.btnSave);
        btnSign = (Button) findViewById(R.id.btnSign);
        lv = (ListView) findViewById(R.id.lv);

        itemList = new ArrayList<Item>();
        adapter = new CustomAdapter();
        lv.setAdapter(adapter);

        editDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);
                DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        dateName = Integer.toString(i) + "_" + Integer.toString(i1+1) + "_" + Integer.toString(i2);
                        editDate.setText(Integer.toString(i) + "년 " + Integer.toString(i1+1) + "월 " + Integer.toString(i2)+ "일 ") ;
                    }
                };
                DatePickerDialog pickerDialog = new DatePickerDialog(Third.this, listener, year, month, day);
                pickerDialog.show();
            }
        });

        editTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);
                TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        timeName = Integer.toString(i)+"_"+Integer.toString(i1);
                        editTime.setText(i + "시 " + i1 + "분")   ;
                    }
                };
                TimePickerDialog timePickerDialog = new TimePickerDialog(Third.this, listener, hour, minute, true);
                timePickerDialog.setTitle("시간을 선택하세요");
                timePickerDialog.show();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fileName = dateName +"_"+ timeName+".txt";
                try {
                    FileOutputStream fos = openFileOutput(fileName, Context.MODE_PRIVATE);
                    String title = "제목 : " + editTitle.getText().toString() + "\n";
                    String con = "내용 : " + editCon.getText().toString();
                    fos.write(title.getBytes());
                    fos.write(con.getBytes());
                    fos.close();
                    Toast.makeText(getApplicationContext(), "저장 완료", Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    Toast.makeText(getApplicationContext(), "저장이 안됨", Toast.LENGTH_LONG).show();
                }

                String name = editDate.getText().toString() + editTime.getText().toString();
                String phone = editTitle.getText().toString();
                Toast.makeText(getApplicationContext(), name + phone, Toast.LENGTH_SHORT).show();
                itemList.add(new Item(name, phone));
                adapter.notifyDataSetChanged();
            }
        });

        btnSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Four.class);
                startActivity(intent);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(1,1,0, "초기 화면");
        menu.add(1,2,0, "끝내기");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == 1){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == 2){
            finishAffinity();
        }
        return false;
    }

    private class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return itemList.size();
        }

        @Override
        public Object getItem(int position) {
            return itemList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewgroup) {
            if(view == null){
                view = LayoutInflater.from(Third.this).inflate(R.layout.list_item, viewgroup, false);
            }

            Item item = itemList.get(i);

            TextView itemName = view.findViewById(R.id.tvList1);
            TextView itemDescription = view.findViewById(R.id.tvList2);

            itemName.setText(item.name);
            itemDescription.setText(item.description);
            return view;
        }
    }
    private  class Item {
        String name;
        String description;

        Item(String name, String description){
            this.name = name;
            this.description = description;
        }
    }
}

