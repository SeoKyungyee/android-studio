package com.example.jsk_202310491;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;

import com.example.jsk_202310491.MainActivity;
import com.example.jsk_202310491.R;

public class Second extends AppCompatActivity {

    Button button4 ;
    EditText editText3,editText4, editText5;

    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);

        button4 = (Button) findViewById(R.id.button4);
        editText3 = (EditText) findViewById(R.id.editText3);
        editText4 = (EditText) findViewById(R.id.editText4);
        editText5 = (EditText) findViewById(R.id.editText5);

        String text3 = editText4.getText().toString();
        String text4 = editText5.getText().toString();

        String text1 = getIntent().getStringExtra("text1");
        String text2 = getIntent().getStringExtra("text2");

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.putExtra("text1", text1);
                intent.putExtra("text2", text2);
                setResult(RESULT_OK, intent);



                String name = editText3.getText().toString();
                String gkrqjs = editText4.getText().toString();
                String text4 = editText5.getText().toString();

                Intent intent5 = new Intent(Second. this, Third.class);
                intent5.putExtra("userName", name);
                intent5.putExtra("gkrqjs", gkrqjs);
                intent5.putExtra("text4", text4);
                setResult(RESULT_OK, intent5);
                startActivity(intent5);

            }
        });
    }
}

