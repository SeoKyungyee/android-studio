package com.example.jsk_202310491;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Activity_01 extends Activity {
    Button button7, button8, button9;
    EditText editTextNumber, editTextNumber2;
    int num1, num2;
    Integer result;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_01);
        editTextNumber = (EditText) findViewById(R.id.editTextText);
        editTextNumber2 = (EditText) findViewById(R.id.editTextText2);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);
        button7.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                if ((editTextNumber.getText().length() != 0) && (editTextNumber2.getText().length() != 0)) {
                    num1 = Integer.parseInt(editTextNumber.getText().toString());
                    num2 = Integer.parseInt(editTextNumber2.getText().toString());
                    result = num1 * num2;
                    Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "똑바로 입력하세요.",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextNumber.setText("");
                editTextNumber2.setText("");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }
        });
            }

            }

