package com.example.jsk_202310491;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Activity_02 extends Activity {
    Button button10, button11, button12, button13, button14, button15;
   EditText editTextText3, editTextText4;
    int num1, num2;
    Integer result;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_02);
        editTextText3 = (EditText) findViewById(R.id.editTextText3);
        editTextText4 = (EditText) findViewById(R.id.editTextText4);
        button10 = (Button) findViewById(R.id.button10);
        button11 = (Button) findViewById(R.id.button11);
        button12 = (Button) findViewById(R.id.button12);
        button13 = (Button) findViewById(R.id.button13);
        button14 = (Button) findViewById(R.id.button14);
        button15 = (Button) findViewById(R.id.button15);
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((editTextText3.getText().length() != 0) && (editTextText4.getText().length() != 0)) {
                    num1 = Integer.parseInt(editTextText3.getText().toString());
                    num2 = Integer.parseInt(editTextText4.getText().toString());
                    result = num1 + num2;
                    Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "똑바로 입력하세요.",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((editTextText3.getText().length() != 0) && (editTextText4.getText().length() != 0)) {
                    num1 = Integer.parseInt(editTextText3.getText().toString());
                    num2 = Integer.parseInt(editTextText4.getText().toString());
                    result = num1 - num2;
                    Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "똑바로 입력하세요.",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((editTextText3.getText().length() != 0) && (editTextText4.getText().length() != 0)) {
                    num1 = Integer.parseInt(editTextText3.getText().toString());
                    num2 = Integer.parseInt(editTextText4.getText().toString());
                    result = num1 * num2;
                    Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "똑바로 입력하세요.",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((editTextText3.getText().length() != 0) && (editTextText4.getText().length() != 0)) {
                    num1 = Integer.parseInt(editTextText3.getText().toString());
                    num2 = Integer.parseInt(editTextText4.getText().toString());
                    result = num1 / num2;
                    Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "다시 입력하세요.",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextText3.setText("");
                editTextText4.setText("");
            }
        });
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent2);
            }
        });
    }
}

