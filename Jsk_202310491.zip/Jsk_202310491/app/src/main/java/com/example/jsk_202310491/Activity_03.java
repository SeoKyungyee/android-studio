package com.example.jsk_202310491;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Activity_03 extends Activity {
    Button button16, button17, button18, button19;
    EditText editTextNumber5, editTextNumber6;
    int num1;
    Integer result;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_03);
        editTextNumber5 = (EditText) findViewById(R.id.editTextText5);
        editTextNumber6 = (EditText) findViewById(R.id.editTextText6);
        button16 = (Button) findViewById(R.id.button16);
        button17 = (Button) findViewById(R.id.button17);
        button18 = (Button) findViewById(R.id.button18);
        button19 = (Button) findViewById(R.id.button19);
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editTextNumber5.getText().length() != 0) {
                    num1 = Integer.parseInt(editTextNumber5.getText().toString());
                    result = (2024 - num1) + 1;
                    Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "똑바로 입력해라",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editTextNumber6.getText().length() != 0) {
                    num1 = Integer.parseInt(editTextNumber6.getText().toString());
                    result = (2024 - num1) + 1;
                    Toast.makeText(getApplicationContext(), result.toString(),Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "똑바로 입력해라",Toast.LENGTH_SHORT).show();
                }
            }
        });
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextNumber5.setText("");
                editTextNumber6.setText("");
            }
        });
        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
