package com.example.jsk_202310491;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class Activity_04 extends Activity {
    Button button20, button21, button22;
    RadioButton radioButton, radioButton2;
    TextView textView9;
    Float result;
    float inputvalue;
    EditText editTextNumber7;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_04);
        radioButton = (RadioButton) findViewById(R.id.radioButton);
        radioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        textView9 = (TextView) findViewById(R.id.textView10);
        editTextNumber7 = (EditText) findViewById(R.id.editTextText7);
        button20 = (Button) findViewById(R.id.button20);
        button21 = (Button) findViewById(R.id.button21);
        button22 = (Button) findViewById(R.id.button22);
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editTextNumber7.getText().length() != 0) {
                    if (radioButton.isChecked() == true ){
                        inputvalue = Float.parseFloat(editTextNumber7.getText().toString());
                        result = (inputvalue-32)*5/9;
                        textView9.setText("변환 결과: " + result.toString());
                    } else {
                        inputvalue = Float.parseFloat(editTextNumber7.getText().toString());
                        result = (inputvalue*9/5)+32;
                        textView9.setText("변환 결과: " + result.toString());
                    }
                } else {
                    Toast.makeText(getApplicationContext(),"정확한 값을 입력하세요",Toast.LENGTH_LONG).show();
                }
            };
        });
        button21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextNumber7.setText("");
                textView9.setText("변환 결과:");
            }
        });
        button22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}
