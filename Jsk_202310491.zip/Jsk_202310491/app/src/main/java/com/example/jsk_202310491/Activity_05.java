package com.example.jsk_202310491;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class Activity_05 extends Activity {
    Button button23, button24, button25;
    EditText editTextText8, editTextText9, editTextText10;
    TextView textView15, textView16;
    int num1, num2, num3;
    Integer result, result2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_05);
        textView15 = (TextView) findViewById(R.id.textView15);
        textView16 = (TextView) findViewById(R.id.textView16);
        editTextText8 = (EditText) findViewById(R.id.editTextText8);
        editTextText9 = (EditText) findViewById(R.id.editTextText9);
        editTextText10 = (EditText) findViewById(R.id.editTextText10);
        button23 = (Button) findViewById(R.id.button23);
        button24 = (Button) findViewById(R.id.button24);
        button25 = (Button) findViewById(R.id.button25);
        button23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((editTextText8.getText().length() != 0) && (editTextText9.getText().length() != 0) && (editTextText10.getText().length() != 0)) {
                    num1 = Integer.parseInt(editTextText8.getText().toString());
                    num2 = Integer.parseInt(editTextText9.getText().toString());
                    num3 = Integer.parseInt(editTextText10.getText().toString());
                    result = num1 + num2 + num3;
                    result2 = (num1*15000) + (num2*13000) + (num3*9000);
                    textView15.setText("주문 개수: " + result.toString());
                    textView16.setText("주문 금액: " + result2.toString());
                }
            }
        });
        button24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextText8.setText("");
                editTextText9.setText("");
                editTextText10.setText("");
                textView15.setText("주문 개수:");
                textView16.setText("주문 금액:");
            }
        });
        button25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent5 = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent5);
            }
        });
    }
}
