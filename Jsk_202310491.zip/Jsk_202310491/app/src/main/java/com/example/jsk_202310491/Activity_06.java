package com.example.jsk_202310491;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class Activity_06 extends Activity {
    Button button26, button27, button28;
    EditText editTextText11, editTextText12, editTextText13;
    TextView textView21, textView22;
    int num1, num2, num3;
    Integer result, result2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_06);
        textView21 = (TextView) findViewById(R.id.textView21);
        textView22 = (TextView) findViewById(R.id.textView22);
        editTextText11 = (EditText) findViewById(R.id.editTextText11);
        editTextText12 = (EditText) findViewById(R.id.editTextText12);
        editTextText13 = (EditText) findViewById(R.id.editTextText13);
        button26 = (Button) findViewById(R.id.button26);
        button27 = (Button) findViewById(R.id.button27);
        button28 = (Button) findViewById(R.id.button28);
        button26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ((editTextText11.getText().length() != 0) && (editTextText12.getText().length() != 0) || (editTextText13.getText().length() != 0)) {
                    num1 = Integer.parseInt(editTextText11.getText().toString());
                    num2 = Integer.parseInt(editTextText12.getText().toString());
                    num3 = Integer.parseInt(editTextText13.getText().toString());
                    result = num1 + num2 + num3;
                    result2 = (num1 + num2 + num3) / 3;
                    textView21.setText("총점: " + result.toString());
                    textView22.setText("평균: " + result2.toString());
                }
            }
        });
        button27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextText11.setText("");
                editTextText12.setText("");
                editTextText13.setText("");
                textView21.setText("총점:");
                textView22.setText("평균:");
            }
        });
        button28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}

