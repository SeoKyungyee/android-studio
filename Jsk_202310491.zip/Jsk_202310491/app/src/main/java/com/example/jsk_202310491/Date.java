package com.example.jsk_202310491;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class Date extends AppCompatActivity {
    EditText date_text;
    EditText time_text;
    EditText title_text;
    EditText content_text;
    String dateName, timeName, fileName;
    Button saveBtn, btnSign;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.date_manage);
        setTitle("과제 2 : 일정 관리");
        date_text = (EditText) findViewById(R.id.date_text);
        time_text = (EditText) findViewById(R.id.time_text);
        title_text = (EditText) findViewById(R.id.title_text);
        content_text = (EditText) findViewById(R.id.content_text);
        saveBtn = (Button) findViewById(R.id.saveBtn);
        btnSign = (Button) findViewById(R.id.btnSign);

        date_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);
                DatePickerDialog.OnDateSetListener listener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        dateName = Integer.toString(i) + "_" + Integer.toString(i1+1) + "_" + Integer.toString(i2);
                        date_text.setText(Integer.toString(i) + "년 " + Integer.toString(i1+1) + "월 " + Integer.toString(i2)+ "일 ") ;
                    }
                };
                DatePickerDialog pickerDialog = new DatePickerDialog(Date.this, listener, year, month, day);
                pickerDialog.show();
            }
        });

        time_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);
                TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        timeName = Integer.toString(i)+"_"+Integer.toString(i1);
                        time_text.setText(i + "시 " + i1 + "분")   ;
                    }
                };
                TimePickerDialog timePickerDialog = new TimePickerDialog(Date.this, listener, hour, minute, true);
                timePickerDialog.setTitle("시간을 선택하세요");
                timePickerDialog.show();
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fileName = dateName +"_"+ timeName+".txt";
                try {
                    FileOutputStream fos = openFileOutput(fileName, Context.MODE_PRIVATE);
                    String title = "제목 : " + title_text.getText().toString() + "\n";
                    String con = "내용 : " + content_text.getText().toString();
                    fos.write(title.getBytes());
                    fos.write(con.getBytes());
                    fos.close();
                    Toast.makeText(getApplicationContext(), "저장 완료", Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                }
            }
        });

        btnSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Signature.class);
                startActivity(intent);
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(0,1,0, "초기 화면");
        menu.add(0,2,0, "끝내기");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == 1){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }
        if(item.getItemId() == 2){
            finishAffinity();
        }
        return false;
    }
}
