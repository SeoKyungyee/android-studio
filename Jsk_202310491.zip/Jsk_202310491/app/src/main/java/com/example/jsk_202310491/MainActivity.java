package com.example.jsk_202310491;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView context, main_num, main_pw;;
    String receiveNum, receivePw;
    Button login, cancel, btn_sign;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("과제 2 : 장서경(202310491)");
        context = (TextView) findViewById(R.id.context);
        main_num = (TextView) findViewById(R.id.main_num);
        main_pw = (TextView) findViewById(R.id.main_pw);
        login = (Button) findViewById(R.id.login);
        cancel = (Button) findViewById(R.id.cancel);
        btn_sign = (Button) findViewById(R.id.btn_sign);
        registerForContextMenu(context);

        Intent intent = getIntent();
        receiveNum = intent.getStringExtra("userNum");
        receivePw = intent.getStringExtra("userPw");

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(main_num.getText().toString().equals(receiveNum) && main_pw.getText().toString().equals(receivePw)){
                    Intent intent = new Intent(getApplicationContext(), Date.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "학번과 비밀번호를 확인하세요", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Sign.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(0,1,0, "학과 홈페이지");
        menu.add(0,2,0, "Hello LMS");
        menu.add(0,3,0, "학과 대표 전화");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == 1){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://medis.shu.ac.kr/"));
            startActivity(intent);
            return true;
        }

        if(item.getItemId() == 2){
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://eclass.shu.ac.kr/ilos/main/main_form.acl"));
            startActivity(intent);
            return true;
        }

        if(item.getItemId() == 3){
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:0234078678"));
            startActivity(intent);
            return true;
        }
        return false;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater menuInflater = getMenuInflater();
        if (v == context){
            menuInflater.inflate(R.menu.menu1, menu);
    }
}
    }