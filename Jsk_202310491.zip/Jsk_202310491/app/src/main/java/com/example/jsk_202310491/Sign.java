package com.example.jsk_202310491;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

public class Sign extends AppCompatActivity {
    EditText sign_name, sign_num, sign_pw, sign_pw1, digital_name, digital_num, digital_pw;
    Button btn_check, btn_sign_up;
    View dialogView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in);
        setTitle("과제 2 : 회원가입");
        sign_name = (EditText) findViewById(R.id.sign_name);
        sign_num = (EditText) findViewById(R.id.sign_num);
        sign_pw = (EditText) findViewById(R.id.sign_pw);
        sign_pw1 = (EditText) findViewById(R.id.sign_pw1);
        btn_check = (Button) findViewById(R.id.btn_check);
        btn_sign_up = (Button) findViewById(R.id.btn_sign_up);

        btn_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!sign_pw.getText().toString().equals("")){
                    if(sign_pw.getText().toString().equals(sign_pw1.getText().toString())){
                        Toast.makeText(getApplicationContext(), "비밀번호가 일치합니다.", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(), "비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogView = (View) View.inflate(Sign.this, R.layout.dialog1, null);
                AlertDialog.Builder dlg = new AlertDialog.Builder(Sign.this);
                dlg.setTitle("입력하신 로그인 정보입니다.");
                dlg.setView(dialogView);
                dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        intent.putExtra("userNum", sign_num.getText().toString());
                        intent.putExtra("userPw", sign_pw.getText().toString());
                        startActivity(intent);
                    }
                });
                dlg.setNegativeButton("취소", null);
                digital_name = (EditText) dialogView.findViewById(R.id.digital_name);
                digital_num = (EditText) dialogView.findViewById(R.id.digital_num);
                digital_pw = (EditText) dialogView.findViewById(R.id.digital_pw);
                digital_name.setText(sign_name.getText().toString());
                digital_num.setText(sign_num.getText().toString());
                digital_pw.setText(sign_pw.getText().toString());
                dlg.show();
            }
        });
    }
}
