package com.example.login_a;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class Second extends Activity {
    TextView textView, textView2, textView3;
    Button button2;
    Integer value1, value2, result;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        textView=(TextView) findViewById(R.id.textView);
        textView2=(TextView) findViewById(R.id.textView2);
        textView3=(TextView) findViewById(R.id.textView3);
        button2=(Button) findViewById(R.id.button2);

        Intent in = getIntent();
        value1=in.getIntExtra("num1", 0);
        value2=in.getIntExtra("num2", 0);
        result = value1 + value2;

        textView.setText("입력한 1의 정수 값은: " + value1.toString());
        textView2.setText("입력한 2의 정수 값은: " + value2.toString());
        textView3.setText("더하기 결과: " + result.toString());

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(), Activity.class);
                ;
                startActivity(in);
            }
        });
    }
}

