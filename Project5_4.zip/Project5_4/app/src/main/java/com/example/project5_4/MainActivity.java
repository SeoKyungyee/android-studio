package com.example.project5_4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button button, button2, button3;
    FrameLayout frameRed, frameBlue, frameGreen;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        frameRed = (FrameLayout) findViewById(R.id.frameRed);
        frameBlue = (FrameLayout) findViewById(R.id.frameBlue);
        frameGreen = (FrameLayout) findViewById(R.id.frameGreen);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frameRed.setVisibility(View.VISIBLE);
                frameBlue.setVisibility(View.INVISIBLE);
                frameGreen.setVisibility(View.INVISIBLE);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frameRed.setVisibility(View.INVISIBLE);
                frameBlue.setVisibility(View.VISIBLE);
                frameGreen.setVisibility(View.INVISIBLE);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                frameRed.setVisibility(View.INVISIBLE);
                frameBlue.setVisibility(View.INVISIBLE);
                frameGreen.setVisibility(View.VISIBLE);
            }
        });
    }}
